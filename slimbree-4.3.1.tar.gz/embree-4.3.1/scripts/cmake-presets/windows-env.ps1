## Copyright 2019-2021 Intel Corporation
## SPDX-License-Identifier: Apache-2.0


$env:CMAKE_EXE=cmake